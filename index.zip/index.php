
   <?php include 'layout/header.php';?>

    <div class="container-fluid">
        <div class="row mt-4">
            <div class="col-lg-3">
                <a class="card bg-info" href="doctor.html">
                    <div class="card-body">
                        <h4>Total Doctor</h4>
                        <p class="p-0 m-o">View All</p>
                        <span>3</span>
                    </div>
                </a>
            </div>
            <div class="col-lg-3">
                <a class="card bg-warning" href="hospital.html">
                    <div class="card-body">
                        <h4>Hospitals</h4>
                        <p class="p-0 m-o">All Registered Hospitals</p>
                        <span>200</span>
                    </div>
                </a>
            </div>
            <div class="col-lg-3">
                <a class="card bg-success text-white" href=".html">
                    <div class="card-body">
                        <h4>Appointments</h4>
                        <p class="p-0 m-o">All Registered Appointments</p>
                        <span>15670</span>
                    </div>
                </a>
            </div>
            <div class="col-lg-3">
                <a class="card bg-danger text-white" href="hospital.html">
                    <div class="card-body">
                        <h4>Covid Patients</h4>
                        <p class="p-0 m-o">All Covid Hospitals</p>
                        <span>60</span>
                    </div>
                </a>
            </div>
        </div>
    </div>
    
    <div class="container">
        <div class="row my-4">
            <div class="col-lg-12 text-start">
                <h4>Doctors <a class="btn btn-dark float-end">View More</a></h4>
            </div>
        </div>
        <div class="row justifiy-content-evenly doc-row">
            <div class="col-lg-4 col-md-6">
                <div class="card">
                    <div class="text-center">
                        <img src="img/d1.jpg" class="card-img-top img-fluid" alt="...">
                    </div>
                    <div class="card-body">
                        <h5 class="card-title">Doctor's</h5>
                        <p class="card-text">Some quick example
                            the card's content.</p>
                        <a href="#" class="btn btn-primary">Address </a>
                    </div>
                </div>
            </div>
            <div class="col-lg-4 col-md-6">
                <div class="card">
                    <div class="text-center">
                        <img src="img/d2.jpg" class="card-img-top img-fluid" alt="...">
                    </div>
                    <div class="card-body">
                        <h5 class="card-title">Card title</h5>
                        <p class="card-text">Some quick example text
                            the card's content.</p>
                        <a href="#" class="btn btn-primary">Go somewhere</a>
                    </div>
                </div>
            </div>
            <div class="col-lg-4 col-md-6">
                <div class="card">
                    <div class="text-center">
                        <img src="img/d3.jpg" class="card-img-top img-fluid" alt="...">
                    </div>
                    <div class="card-body">
                        <h5 class="card-title">Card title</h5>
                        <p class="card-text">Some quick example
                            the card's content.</p>
                        <a href="#" class="btn btn-primary">Go somewhere</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <div class="container">
        <div class="row my-4">
            <div class="col-lg-12 text-start">
                <h4>Hospital <a class="btn btn-dark float-end">View More</a></h4>
            </div>
        </div>
        <div class="row justifiy-content-evenly doc-row">
            <div class="col-lg-4 col-md-6">
                <div class="card">
                    <div class="text-center img">
                        <img src="img/d5.jpg" class="card-img-top img-fluid" alt="..."
                            style="width: 416px; height: 238px;">
                    </div>
                    <div class="card-body">
                        <h5 class="card-title">City Hospital</h5>
                        <p class="card-text">New Market</p>
                        <a href="#" class="btn btn-primary">All Details</a>
                    </div>
                </div>
            </div>
            <div class="col-lg-4 col-md-6">
                <div class="card">
                    <div class="text-center img">
                        <img src="img/d6.jpg" class="card-img-top img-fluid" alt="..."
                            style="width: 416px; height: 238px;">
                    </div>
                    <div class="card-body">
                        <h5 class="card-title">Sarda Hospital</h5>
                        <p class="card-text">Nehru Nagar, Bhopal</p>
                        <a href="#" class="btn btn-primary">All Details</a>
                    </div>
                </div>
            </div>
            <div class="col-lg-4 col-md-6">
                <div class="card">
                    <div class="text-center img">
                        <img src="img/d7.jpg" class="card-img-top img-fluid" alt="..."
                            style="width: 416px; height: 238px;">
                    </div>
                    <div class="card-body">
                        <h5 class="card-title">Kotahri Hospital</h5>
                        <p class="card-text">Nehru Nagar, Bhopal</p>
                        <a href="#" class="btn btn-primary">All Details</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
   <?php include 'layout/footer.php' ?>

   
   
   

